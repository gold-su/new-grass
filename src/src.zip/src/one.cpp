#include <iostream>

using namespace std;

int main() {
	cout << "Hello, Wolrd" << endl;
	/*c out은 문장 출력하는 기능
	endl은 줄바꿈 */
	return 0;
}


//c++에는 main 함수 필수
