#include <iostream>

using namespace std;

int main() {
	
	const float PIE = 3.14;
	int a = 5;
	
    float s = a * a * PIE ;
		
	cout << s << endl;
	
	return 0;
}